سوق الحي - souq-alhai

ملف جاهز للرفع على GitHub Pages. ضع إعدادات Firebase في index.html داخل firebaseConfig.